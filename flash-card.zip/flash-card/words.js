

var occupations = [
  "accountant", "acrobat",
];

var whereAreWe = [
  "airport", "apiary", "aquarium", "auditorim", "aviary", "bakery", "ballroom", "basement", "cabin", "cinema",
   "depot", "dockyard", "dormitory", "esplanade", "factory", "fishery", "garage",
   "greenhouse", "gymnasium", "hangar", "headquarters", "hostel", "incinerator", "kindergarten",
   "laboratory", "lake", "mill", "mint", "monastery", "mosque", "museum", "nunnery", "nursery", "orchard",
   "orphanage","plantation","quarry","quay","reservoir", "theatre", "university", "warehouse", "waterfall"
];

var whoAreYou =
[
  "archer" , "bachelor", "bankrupt", "burglar", "cannibal", "carnivore", "herbivore", "citizen" ,
  "convict", "criminal", "customer",
  "emigrant", "immigrant", "fugitive", "glutton", "guest", "host", "hotess", "linguist", "mimic", "miser", "motorist", "nomad", "onlooker",
  "paramedic", "passenger", "patriot", "pedestrian", "robber", "spendthrift", "spinster","truant", "vegetarian"
];



var occupationsCategory = new Category(occupations, "#d0d6e2", "rgb(242, 153, 160)", "", "Occupations");
var whoAreYouCategory = new Category(whoAreYou, "#fff700", "#C85073", "", "Who Are You");
var whereAreWeCategory = new Category(whereAreWe, "#dac2c7", "rgb(66, 98, 140)", "", "Where are we");

var categories = [
      //occupationsCategory,
      whoAreYouCategory,
      //whereAreWeCategory
];

var enableCategories = [

];

var categoryMap = new Map(
  [occupationsCategory.label, occupationsCategory],
  [whoAreYouCategory.label, whoAreYouCategory],
  [whereAreWeCategory.label, whereAreWeCategory]
);
