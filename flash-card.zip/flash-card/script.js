

function start() {

  var dictionary = readDictionary();
  var html="";
  var index = 0;
  var cellPerRow = 6;

  dictionary.forEach(function(word) {
    if(index % cellPerRow == 0 ) {
      html += "<div class='divTableRow'>";
    }

    html += "<div class='divTableCell'>";
    html += word.toHtml();
    html += "</div>"

    if(index % cellPerRow == (cellPerRow - 1)) {
      html += "</div>";
    }
    index++;
  });

  $("#body_div").html(html);

}

function readDictionary() {
  var dictionary = new Array();
  var id = 0;

  categories.forEach(function(category) {
    category.words.forEach(function(word) {
      dictionary.push(new Word(id, word, category.textColor, category.bgColor, category.bgImage, category.label));
      id++;
    });
  });
  return dictionary;
}

start();
